/*
 * Copyright 2015-2022 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.hasor.dbvisitor.fakerboot;
import net.hasor.cobble.StringUtils;
import net.hasor.cobble.SystemUtils;
import net.hasor.cobble.setting.Settings;
import org.apache.commons.cli.*;
import org.apache.maven.cli.MavenCli;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @version : 2022-04-29
 * @author 赵永春 (zyc@hasor.net)
 */
public class FakerBoot {
    public static void main(String[] args) throws ParseException {
        Options options = new Options();
        options.addOption("u", true, "database username.");
        options.addOption("p", true, "database password");
        options.addOption("t", true, "run times");
        options.addOption("s", true, "faker config file.");
        options.addOption("m", true, "using maven setting file.");

        // -h jdbc
        // -s
        // table expr
        //
        //
        CommandLineParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, args);

        File settingFile = null;
        if (cmd.hasOption("m")) {

        }

        String userHome = System.getProperty("user.home");
        if (settingFile == null && StringUtils.isNotBlank(userHome)) {
            File tempFile = new File(userHome, "/.m2/settings.xml");
            if (tempFile.exists()) {
                settingFile = tempFile;
            }
        }
        String m2Home = SystemUtils.getSystemProperty("M2_HOME");
        if (settingFile == null && StringUtils.isNotBlank(m2Home)) {
            File tempFile = new File(m2Home, "/settings.xml");
            if (tempFile.exists()) {
                settingFile = tempFile;
            }
        }
        if (settingFile == null) {
            File tempFile = new File(m2Home, "/settings.xml");
            if (tempFile.exists()) {
                settingFile = tempFile;
            }
        }

        //
        System.out.println("ss");
    }

    private Settings readSetting() {
        new org.apache.maven.settings.Settings()
    }

    public static void copy(File workingDirectory, File localRepository, File settings) {
        if (!workingDirectory.exists()) {
            throw new RuntimeException("指定的maven工程不存在：" + workingDirectory.toString());
        }
        if (!localRepository.exists()) {
            throw new RuntimeException("指定maven本地仓库不存在：" + localRepository.toString());
        }
        if (!settings.exists()) {
            throw new RuntimeException("指定settings.xml文件不存在：" + settings.toString());
        }

        List<String> cliList = new ArrayList<>();
        cliList.add("-Dmaven.repo.local=" + localRepository.getCanonicalPath());
        cliList.add("-gs=" + settings.getCanonicalPath());
        cliList.add("-DoutputDirectory=./target/lib");
        cliList.add("dependency:copy-dependencies");

        MavenCli cli = new MavenCli();
        cli.doMain() System.getProperties().setProperty("maven.multiModuleProjectDirectory", "$M2_HOME");

        int status = cli.doMain(cliList.toArray(new String[0]), workingDirectory.getCanonicalPath(), null, null);
        if (status > 0) {
            throw new RuntimeException("复制依赖的jar到target/lib出错,code=" + status);
        }
    }
}