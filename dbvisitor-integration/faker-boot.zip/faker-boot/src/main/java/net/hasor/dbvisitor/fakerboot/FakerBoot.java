/*
 * Copyright 2015-2022 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.hasor.dbvisitor.fakerboot;
import net.hasor.cobble.StringUtils;
import net.hasor.cobble.SystemUtils;
import net.hasor.cobble.setting.Settings;
import org.apache.commons.cli.*;
import org.apache.maven.cli.CliRequest;
import org.apache.maven.cli.MavenCli;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 赵永春 (zyc@hasor.net)
 * @version : 2022-04-29
 */
public class FakerBoot {

    private static File parseMavenSettings(CommandLine cmdArgs) {
        if (cmdArgs.hasOption("mavenConfig")) {
            String mavenConfig = cmdArgs.getOptionValue("mavenConfig");
            File tempFile = new File(mavenConfig);
            if (tempFile.exists()) {
                return tempFile;
            }
        }

        String userHome = System.getProperty("user.home");
        if (StringUtils.isNotBlank(userHome)) {
            File tempFile = new File(userHome, "/.m2/settings.xml");
            if (tempFile.exists()) {
                return tempFile;
            }
        }

        String m2Home = SystemUtils.getSystemProperty("M2_HOME");
        if (StringUtils.isNotBlank(m2Home)) {
            File tempFile = new File(m2Home, "conf/settings.xml");
            if (tempFile.exists()) {
                return tempFile;
            }
        }

        return null;
    }

    private static File parseMavenProjectHome(CommandLine cmdArgs, Settings settings) {

    }

    public static void main(String[] args) throws ParseException {
        Options options = new Options();
        // maven
        options.addOption(Option.builder("m").longOpt("maven").argName("mavenConfig").hasArg().desc("using maven setting file.").build());
        options.addOption(Option.builder("r").longOpt("repo").argName("localRepository").hasArg().desc("using maven localRepository.").build());
        options.addOption(Option.builder("l").longOpt("library").argName("library").hasArg().desc("using local classpath.").build());
        // jdbc params
        options.addOption(Option.builder("h").longOpt("jdbcURL").argName("jdbcURL").hasArg().desc("database jdbcURL.").build());
        options.addOption(Option.builder("u").longOpt("user").argName("user").hasArg().desc("database username.").build());
        options.addOption(Option.builder("p").longOpt("password").argName("password").hasArg().desc("database password").build());
        options.addOption(Option.builder("D").hasArgs().valueSeparator('=').desc("jdbc params").build());
        // run
        options.addOption(Option.builder("t").longOpt("times").argName("runTimes").hasArg().desc("execute Faker time second.").build());

        CommandLineParser parser = new DefaultParser();
        CommandLine cmdArgs = parser.parse(options, args);

        File mavenSettings = parseMavenSettings(cmdArgs);

        //
        System.out.println("ss");
    }

    public static void copy(File workingDirectory, File localRepository, File settings) {
        if (!workingDirectory.exists()) {
            throw new RuntimeException("指定的maven工程不存在：" + workingDirectory.toString());
        }
        if (!localRepository.exists()) {
            throw new RuntimeException("指定maven本地仓库不存在：" + localRepository.toString());
        }
        if (!settings.exists()) {
            throw new RuntimeException("指定settings.xml文件不存在：" + settings.toString());
        }

        List<String> cliList = new ArrayList<>();
        cliList.add("-Dmaven.repo.local=" + localRepository.getCanonicalPath());
        cliList.add("-gs=" + settings.getCanonicalPath());
        cliList.add("-DoutputDirectory=./target/lib");
        cliList.add("dependency:copy-dependencies");

        MavenCli cli = new MavenCli();
        CliRequest cliRequest = new CliRequest();

        cli.doMain(cliRequest);
        System.getProperties().setProperty("maven.multiModuleProjectDirectory", "$M2_HOME");

        int status = cli.doMain(cliList.toArray(new String[0]), workingDirectory.getCanonicalPath(), null, null);
        if (status > 0) {
            throw new RuntimeException("复制依赖的jar到target/lib出错,code=" + status);
        }
    }
}